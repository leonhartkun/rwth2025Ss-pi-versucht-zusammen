var config_8h =
[
    [ "AUSFUEHRLICH", "config_8h.html#a9058bd9e8ca401d73675e86e4bbc8adf", null ],
    [ "COMPUTER", "config_8h.html#a51d3d2b0998c1ec1f626c905822c26f3", null ],
    [ "GROESSE_X", "config_8h.html#a091c112fc29d1116c224f3d4c0fa7455", null ],
    [ "GROESSE_Y", "config_8h.html#a6e8c64412a620a46fbadb6bbf2df47fe", null ],
    [ "MENSCH", "config_8h.html#a38d600df1a68462673f8e46bf9458ddb", null ],
    [ "TEST", "config_8h.html#a5719694a3e41e6610a8dfc42f73bc0b4", null ]
];