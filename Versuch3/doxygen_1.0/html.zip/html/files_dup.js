var files_dup =
[
    [ "config.h", "config_8h.html", "config_8h" ],
    [ "othello.cpp", "othello_8cpp.html", "othello_8cpp" ],
    [ "othelloKI.cpp", "othello_k_i_8cpp.html", "othello_k_i_8cpp" ],
    [ "othelloKI.h", "othello_k_i_8h.html", "othello_k_i_8h" ],
    [ "test.cpp", "test_8cpp.html", "test_8cpp" ],
    [ "test.h", "test_8h.html", "test_8h" ]
];