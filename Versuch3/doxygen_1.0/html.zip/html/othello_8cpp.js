var othello_8cpp =
[
    [ "GROESSE_X", "othello_8cpp.html#a3322848d058541586acfd1cfaf34d1de", null ],
    [ "GROESSE_Y", "othello_8cpp.html#ade6a6629eef71d4b84aaf7471964042b", null ],
    [ "aufSpielfeld", "othello_8cpp.html#a6ded08a0017d5e8a5909d8ce403058fa", null ],
    [ "gewinner", "othello_8cpp.html#ab5b9afa274ecde39b15429f5fc77b59e", null ],
    [ "initialisiereSpielfeld", "othello_8cpp.html#a5c2aa50af4bb13bc589b835e1c1473bc", null ],
    [ "main", "othello_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "menschlicherZug", "othello_8cpp.html#ae44cf481fe71ebc30511c76190e6bc5d", null ],
    [ "moeglicheZuege", "othello_8cpp.html#a8cf3121558de67463e88957becd116d1", null ],
    [ "spielen", "othello_8cpp.html#a596345e24a803c4d6cc0880cdd9c6788", null ],
    [ "zeigeSpielfeld", "othello_8cpp.html#ace1027b2745225e26a5ffb243cf24a15", null ],
    [ "zugAusfuehren", "othello_8cpp.html#a7034afa60f015a8ab6c0b836d316d4a4", null ],
    [ "zugGueltig", "othello_8cpp.html#a0f17ff75622987b979767417e76164a0", null ]
];