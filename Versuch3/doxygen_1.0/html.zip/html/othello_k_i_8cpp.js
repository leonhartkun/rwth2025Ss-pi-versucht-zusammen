var othello_k_i_8cpp =
[
    [ "computerZug", "othello_k_i_8cpp.html#a5e5980177c60019445f26e3e61b50c51", null ],
    [ "moeglicheZuege", "othello_k_i_8cpp.html#a8cf3121558de67463e88957becd116d1", null ],
    [ "zugAusfuehren", "othello_k_i_8cpp.html#a7034afa60f015a8ab6c0b836d316d4a4", null ],
    [ "zugGueltig", "othello_k_i_8cpp.html#a0f17ff75622987b979767417e76164a0", null ]
];