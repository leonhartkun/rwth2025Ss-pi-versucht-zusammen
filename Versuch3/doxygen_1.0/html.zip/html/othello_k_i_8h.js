var othello_k_i_8h =
[
    [ "computerZug", "othello_k_i_8h.html#a5e5980177c60019445f26e3e61b50c51", null ]
];