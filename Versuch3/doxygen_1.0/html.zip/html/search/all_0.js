var searchData=
[
  ['aufspielfeld_0',['aufSpielfeld',['../othello_8cpp.html#a6ded08a0017d5e8a5909d8ce403058fa',1,'aufSpielfeld(const int posX, const int posY):&#160;othello.cpp'],['../test_8cpp.html#a6ded08a0017d5e8a5909d8ce403058fa',1,'aufSpielfeld(const int posX, const int posY):&#160;othello.cpp']]],
  ['aufspielfeldtest_1',['aufSpielfeldTest',['../test_8cpp.html#abed33357222cced27f6a71dfcef7f0dc',1,'aufSpielfeldTest(const int posX, const int posY, const bool richtig, const int testNummer):&#160;test.cpp'],['../test_8h.html#adf20bb7dbcb215d9e7e7a3c90c1bb9b5',1,'aufSpielfeldTest(...):&#160;test.h']]],
  ['ausfuehrlich_2',['AUSFUEHRLICH',['../config_8h.html#a9058bd9e8ca401d73675e86e4bbc8adf',1,'config.h']]]
];
