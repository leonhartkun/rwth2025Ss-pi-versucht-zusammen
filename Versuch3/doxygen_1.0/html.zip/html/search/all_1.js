var searchData=
[
  ['computer_0',['COMPUTER',['../config_8h.html#a51d3d2b0998c1ec1f626c905822c26f3',1,'config.h']]],
  ['computerzug_1',['computerZug',['../othello_k_i_8cpp.html#a5e5980177c60019445f26e3e61b50c51',1,'computerZug(int spielfeld[GROESSE_Y][GROESSE_X], const int aktuellerSpieler):&#160;othelloKI.cpp'],['../othello_k_i_8h.html#a5e5980177c60019445f26e3e61b50c51',1,'computerZug(int spielfeld[GROESSE_Y][GROESSE_X], const int aktuellerSpieler):&#160;othelloKI.cpp']]],
  ['config_2eh_2',['config.h',['../config_8h.html',1,'']]]
];
