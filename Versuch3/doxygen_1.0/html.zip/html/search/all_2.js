var searchData=
[
  ['ganzentestausfuehren_0',['ganzenTestAusfuehren',['../test_8cpp.html#a9c8c940467219dd9a3a51312c61bcf83',1,'ganzenTestAusfuehren():&#160;test.cpp'],['../test_8h.html#a9c8c940467219dd9a3a51312c61bcf83',1,'ganzenTestAusfuehren():&#160;test.cpp']]],
  ['gewinner_1',['gewinner',['../othello_8cpp.html#ab5b9afa274ecde39b15429f5fc77b59e',1,'gewinner(const int spielfeld[GROESSE_Y][GROESSE_X]):&#160;othello.cpp'],['../test_8cpp.html#ab5b9afa274ecde39b15429f5fc77b59e',1,'gewinner(const int spielfeld[GROESSE_Y][GROESSE_X]):&#160;othello.cpp']]],
  ['gewinnertest_2',['gewinnerTest',['../test_8cpp.html#abd7dc9f35ce7c4d7c9bb5c8075c9722f',1,'gewinnerTest(const int eingabefeld[GROESSE_Y][GROESSE_X], const int richtig, const int testNummer):&#160;test.cpp'],['../test_8h.html#a81255b327743be72f619bcdc8d513e91',1,'gewinnerTest(...):&#160;test.h']]],
  ['groesse_5fx_3',['GROESSE_X',['../othello_8cpp.html#a3322848d058541586acfd1cfaf34d1de',1,'GROESSE_X:&#160;othello.cpp'],['../config_8h.html#a091c112fc29d1116c224f3d4c0fa7455',1,'GROESSE_X:&#160;config.h']]],
  ['groesse_5fy_4',['GROESSE_Y',['../othello_8cpp.html#ade6a6629eef71d4b84aaf7471964042b',1,'GROESSE_Y:&#160;othello.cpp'],['../config_8h.html#a6e8c64412a620a46fbadb6bbf2df47fe',1,'GROESSE_Y:&#160;config.h']]]
];
