var searchData=
[
  ['initialisierespielfeld_0',['initialisiereSpielfeld',['../othello_8cpp.html#a5c2aa50af4bb13bc589b835e1c1473bc',1,'othello.cpp']]]
];
