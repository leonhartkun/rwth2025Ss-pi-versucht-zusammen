var searchData=
[
  ['othello_0',['Othello',['../index.html',1,'']]],
  ['othello_2ecpp_1',['othello.cpp',['../othello_8cpp.html',1,'']]],
  ['othelloki_2ecpp_2',['othelloKI.cpp',['../othello_k_i_8cpp.html',1,'']]],
  ['othelloki_2eh_3',['othelloKI.h',['../othello_k_i_8h.html',1,'']]]
];
