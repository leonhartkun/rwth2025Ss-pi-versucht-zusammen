var searchData=
[
  ['spielen_0',['spielen',['../othello_8cpp.html#a596345e24a803c4d6cc0880cdd9c6788',1,'othello.cpp']]]
];
