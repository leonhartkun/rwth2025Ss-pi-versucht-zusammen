var searchData=
[
  ['groesse_5fx_0',['GROESSE_X',['../othello_8cpp.html#a3322848d058541586acfd1cfaf34d1de',1,'othello.cpp']]],
  ['groesse_5fy_1',['GROESSE_Y',['../othello_8cpp.html#ade6a6629eef71d4b84aaf7471964042b',1,'othello.cpp']]]
];
