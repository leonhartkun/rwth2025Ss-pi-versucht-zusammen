var searchData=
[
  ['othello_2ecpp_0',['othello.cpp',['../othello_8cpp.html',1,'']]],
  ['othelloki_2ecpp_1',['othelloKI.cpp',['../othello_k_i_8cpp.html',1,'']]],
  ['othelloki_2eh_2',['othelloKI.h',['../othello_k_i_8h.html',1,'']]]
];
