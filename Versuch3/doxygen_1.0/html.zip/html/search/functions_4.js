var searchData=
[
  ['main_0',['main',['../othello_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'othello.cpp']]],
  ['menschlicherzug_1',['menschlicherZug',['../othello_8cpp.html#ae44cf481fe71ebc30511c76190e6bc5d',1,'othello.cpp']]],
  ['moeglichezuege_2',['moeglicheZuege',['../othello_8cpp.html#a8cf3121558de67463e88957becd116d1',1,'moeglicheZuege(const int spielfeld[GROESSE_Y][GROESSE_X], const int aktuellerSpieler):&#160;othello.cpp'],['../othello_k_i_8cpp.html#a8cf3121558de67463e88957becd116d1',1,'moeglicheZuege(const int spielfeld[GROESSE_Y][GROESSE_X], const int aktuellerSpieler):&#160;othello.cpp'],['../test_8cpp.html#a0e489dcd4ea9e8df2a402eb1754f6fca',1,'moeglicheZuege(const int spielfeld[GROESSE_Y][GROESSE_X], const int player):&#160;othello.cpp']]],
  ['moeglichezuegetest_3',['moeglicheZuegeTest',['../test_8cpp.html#aa97a66b2a8d5268d1ca0a2407fc1cf7b',1,'moeglicheZuegeTest(const int eingabeFeld[GROESSE_Y][GROESSE_X], const int spieler, const int richtig, const int testNummer):&#160;test.cpp'],['../test_8h.html#aedbcf88d0d8bb1dadd4f43597b47be23',1,'moeglicheZuegeTest(...):&#160;test.h']]]
];
