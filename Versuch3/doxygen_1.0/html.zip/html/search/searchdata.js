var indexSectionsWithContent =
{
  0: "acgimostz",
  1: "cot",
  2: "acgimsz",
  3: "acgmt",
  4: "gt",
  5: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "defines",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables",
  4: "Macros",
  5: "Pages"
};

