var searchData=
[
  ['ausfuehrlich_0',['AUSFUEHRLICH',['../config_8h.html#a9058bd9e8ca401d73675e86e4bbc8adf',1,'config.h']]]
];
