var searchData=
[
  ['computer_0',['COMPUTER',['../config_8h.html#a51d3d2b0998c1ec1f626c905822c26f3',1,'config.h']]]
];
