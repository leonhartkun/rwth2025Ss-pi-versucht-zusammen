var searchData=
[
  ['groesse_5fx_0',['GROESSE_X',['../config_8h.html#a091c112fc29d1116c224f3d4c0fa7455',1,'config.h']]],
  ['groesse_5fy_1',['GROESSE_Y',['../config_8h.html#a6e8c64412a620a46fbadb6bbf2df47fe',1,'config.h']]]
];
