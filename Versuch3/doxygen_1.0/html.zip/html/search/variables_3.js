var searchData=
[
  ['mensch_0',['MENSCH',['../config_8h.html#a38d600df1a68462673f8e46bf9458ddb',1,'config.h']]]
];
