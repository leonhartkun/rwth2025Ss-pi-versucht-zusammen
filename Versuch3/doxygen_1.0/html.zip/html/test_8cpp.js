var test_8cpp =
[
    [ "aufSpielfeld", "test_8cpp.html#a6ded08a0017d5e8a5909d8ce403058fa", null ],
    [ "aufSpielfeldTest", "test_8cpp.html#abed33357222cced27f6a71dfcef7f0dc", null ],
    [ "ganzenTestAusfuehren", "test_8cpp.html#a9c8c940467219dd9a3a51312c61bcf83", null ],
    [ "gewinner", "test_8cpp.html#ab5b9afa274ecde39b15429f5fc77b59e", null ],
    [ "gewinnerTest", "test_8cpp.html#abd7dc9f35ce7c4d7c9bb5c8075c9722f", null ],
    [ "moeglicheZuege", "test_8cpp.html#a0e489dcd4ea9e8df2a402eb1754f6fca", null ],
    [ "moeglicheZuegeTest", "test_8cpp.html#aa97a66b2a8d5268d1ca0a2407fc1cf7b", null ],
    [ "zeigeSpielfeld", "test_8cpp.html#ace1027b2745225e26a5ffb243cf24a15", null ],
    [ "zugAusfuehren", "test_8cpp.html#a9a96d91998389b5b92ae11bee6382caa", null ],
    [ "zugAusfuehrenTest", "test_8cpp.html#a1ac824b77843882a5a81c2589dc0b4a3", null ],
    [ "zugGueltig", "test_8cpp.html#ab141dfe59d6487353be7ec47b5d9a14c", null ],
    [ "zugGueltigTest", "test_8cpp.html#a07b607020a2ae0bc390922f6b1010d7e", null ]
];