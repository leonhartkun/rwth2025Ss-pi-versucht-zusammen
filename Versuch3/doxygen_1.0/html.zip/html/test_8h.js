var test_8h =
[
    [ "TESTFUNKTIONEN_H", "test_8h.html#afde064dd5df5d3f3207ebaedb28a5f30", null ],
    [ "aufSpielfeldTest", "test_8h.html#adf20bb7dbcb215d9e7e7a3c90c1bb9b5", null ],
    [ "ganzenTestAusfuehren", "test_8h.html#a9c8c940467219dd9a3a51312c61bcf83", null ],
    [ "gewinnerTest", "test_8h.html#a81255b327743be72f619bcdc8d513e91", null ],
    [ "moeglicheZuegeTest", "test_8h.html#aedbcf88d0d8bb1dadd4f43597b47be23", null ],
    [ "zugAusfuehrenTest", "test_8h.html#a5a5ecc9809e5279f5845e7427350f489", null ],
    [ "zugGueltigTest", "test_8h.html#ae2a0b371cd5eab6469795b69f1a8005f", null ]
];